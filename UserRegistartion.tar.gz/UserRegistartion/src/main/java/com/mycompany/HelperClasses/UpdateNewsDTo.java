/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.HelperClasses;

/**
 *
 * @author root
 */
public class UpdateNewsDTo {

    private String date;
    private String day;
    private String examname;
    private String Class1;
    private String examtime;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getExamname() {
        return examname;
    }

    public void setExamname(String examname) {
        this.examname = examname;
    }

    public String getClass1() {
        return Class1;
    }

    public void setClass1(String Class1) {
        this.Class1 = Class1;
    }

   

    public String getExamtime() {
        return examtime;
    }

    public void setExamtime(String examtime) {
        this.examtime = examtime;
    }
    

}
