/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.constants;

/**
 *
 * @author root
 */
public class QueryConstanst {
    
public static final String INSERT_QUERY= "insert into admins (admin_name,admin_password) values(?,?)";
}
